---
name: apply-chinese-legal-word-format
description: Apply the user's confirmed default typography and paragraph indentation to every Word/DOCX document created or edited for them, especially Chinese legal documents. Use whenever producing or reformatting a .docx unless the current request explicitly overrides these settings. Enforce Chinese/Latin font separation, Chinese point-size names, bold legal section headings such as 诉讼请求 or 事实和理由, and a two-character first-line indent on every paragraph.
---

# Apply Chinese Legal Word Format

Use this skill together with the installed Documents skill. This skill controls only fonts, sizes, heading boldness, and first-line indentation; preserve or decide all other layout properties from the current task or source document.

## 民事起诉状专门格式

生成、修改或核对民事起诉状时，必须先读取并应用 `../civil-complaint-format/SKILL.md`，无须用户重复要求。用户2026年9月29日确认的起诉状专门规则及脱敏母版优先：标题22pt、正文及黑体加粗小标题14pt，保留其角色缩进和版式。此类文书不要直接运行下述通用18pt/12pt格式脚本覆盖专门格式；改用专门技能的检查脚本及逐页渲染核验。其他文书仍按本技能原有默认值。

## Workflow

1. Read `references/word-format.json` completely before authoring or editing a DOCX.
2. Apply the current user's task-specific instruction first. Use this saved configuration for every property the current request does not override.
3. For new documents, use the configured Word styles from the start. For an existing or already-authored DOCX, run:

   ```bash
   <workspace-python> scripts/apply_word_format.py apply input.docx output.docx --auto-classify
   ```

   Resolve `<workspace-python>` through the Codex workspace dependency loader; do not use system Python.
4. Assign roles explicitly when authoring:
   - `User Legal Title`: the document's main title.
   - `User Legal Section Heading`: section headings, including `诉讼请求`, `事实理由`, `事实和理由`, and equivalent headings.
   - `User Legal Body`: body text and all other content.
5. Apply the two-character first-line indent to every paragraph, including titles, headings, body text, table-cell paragraphs, headers, and footers. Preserve list/numbering structure, but do not omit the saved indent unless the current user request overrides it.
6. Verify the generated file structurally:

   ```bash
   <workspace-python> scripts/apply_word_format.py verify output.docx
   ```

7. Follow the Documents skill's render-and-inspect gate: render every page to PNG, inspect all pages, correct defects, and re-render before delivery.

   If `render_docx.py` drops Chinese glyphs because the requested fonts are unavailable to LibreOffice, do not substitute fonts in the final DOCX. Complete the structural verification, then inspect the same final DOCX through Microsoft Word or macOS Quick Look and disclose the fallback renderer used.

## Boundaries

- Do not infer new spacing, alignment, margins, line spacing, colors, numbering, or page geometry from the reference DOCX. Those properties remain task-specific.
- `assets/word-format-reference.docx` is a visual and style reference, not a mandatory content template.
- If a source document contains text boxes, equations, charts, or embedded objects, inspect their typography separately because `python-docx` may not expose all internal paragraphs.
- This formatting skill does not replace legal research, evidence review, or legal drafting skills when the task also involves substantive legal work.
