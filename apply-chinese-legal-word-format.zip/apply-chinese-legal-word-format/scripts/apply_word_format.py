#!/usr/bin/env python3
"""Create, apply, and verify the user's saved Chinese Word typography."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Iterable, Iterator

from docx import Document
from docx.document import Document as DocumentObject
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt
from docx.table import Table
from docx.text.paragraph import Paragraph


SKILL_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = SKILL_ROOT / "references" / "word-format.json"


def load_config(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def get_or_add_rfonts(rpr):
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    return rfonts


def set_font_slots(rpr, chinese_font: str, latin_font: str) -> None:
    rfonts = get_or_add_rfonts(rpr)
    for slot in ("ascii", "hAnsi", "cs"):
        rfonts.set(qn(f"w:{slot}"), latin_font)
    rfonts.set(qn("w:eastAsia"), chinese_font)
    for theme_slot in ("asciiTheme", "hAnsiTheme", "eastAsiaTheme", "cstheme"):
        rfonts.attrib.pop(qn(f"w:{theme_slot}"), None)


def get_or_add_ind(ppr):
    ind = ppr.find(qn("w:ind"))
    if ind is None:
        ind = OxmlElement("w:ind")
        ppr.append(ind)
    return ind


def set_two_character_indent(paragraph_or_style, chars: int, fallback_pt: float) -> None:
    paragraph_or_style.paragraph_format.first_line_indent = Pt(fallback_pt)
    if isinstance(paragraph_or_style, Paragraph):
        ppr = paragraph_or_style._p.get_or_add_pPr()
    else:
        ppr = paragraph_or_style._element.get_or_add_pPr()
    ind = get_or_add_ind(ppr)
    ind.attrib.pop(qn("w:hanging"), None)
    ind.attrib.pop(qn("w:hangingChars"), None)
    ind.set(qn("w:firstLine"), str(round(fallback_pt * 20)))
    ind.set(qn("w:firstLineChars"), str(chars * 100))


def set_style_role(style, role: dict) -> None:
    latin_font = role["latin_font"]
    chinese_font = role["chinese_font"]
    style.font.name = latin_font
    style.font.size = Pt(role["font_size_pt"])
    if role["bold"] is not None:
        style.font.bold = bool(role["bold"])
    set_font_slots(style._element.get_or_add_rPr(), chinese_font, latin_font)
    set_two_character_indent(
        style,
        role["first_line_indent_chars"],
        role["first_line_indent_fallback_pt"],
    )


def set_run_role(run, role: dict) -> None:
    latin_font = role["latin_font"]
    chinese_font = role["chinese_font"]
    run.font.name = latin_font
    run.font.size = Pt(role["font_size_pt"])
    if role["bold"] is not None:
        run.bold = bool(role["bold"])
    set_font_slots(run._r.get_or_add_rPr(), chinese_font, latin_font)


def ensure_style(document: DocumentObject, style_name: str, role: dict):
    styles = document.styles
    if style_name in styles:
        style = styles[style_name]
    else:
        style = styles.add_style(style_name, WD_STYLE_TYPE.PARAGRAPH)
    set_style_role(style, role)
    return style


def install_styles(document: DocumentObject, config: dict) -> dict[str, object]:
    installed = {}
    for role_name, role in config["roles"].items():
        installed[role_name] = ensure_style(document, role["style_name"], role)
    for role_name, built_ins in config["built_in_style_bindings"].items():
        role = config["roles"][role_name]
        for style_name in built_ins:
            if style_name in document.styles:
                set_style_role(document.styles[style_name], role)
    return installed


def iter_table_paragraphs(table: Table) -> Iterator[Paragraph]:
    for row in table.rows:
        for cell in row.cells:
            yield from iter_container_paragraphs(cell)


def iter_container_paragraphs(container) -> Iterator[Paragraph]:
    for paragraph in container.paragraphs:
        yield paragraph
    for table in container.tables:
        yield from iter_table_paragraphs(table)


def iter_all_paragraphs(document: DocumentObject) -> Iterator[Paragraph]:
    seen = set()
    containers = [document]
    for section in document.sections:
        containers.extend([section.header, section.footer])
    for container in containers:
        for paragraph in iter_container_paragraphs(container):
            marker = paragraph._p
            if marker not in seen:
                seen.add(marker)
                yield paragraph


def style_role_map(config: dict) -> dict[str, str]:
    mapping = {}
    for role_name, role in config["roles"].items():
        mapping[role["style_name"]] = role_name
    for role_name, built_ins in config["built_in_style_bindings"].items():
        for name in built_ins:
            mapping[name] = role_name
    return mapping


def classify_paragraphs(document: DocumentObject, config: dict, auto_classify: bool) -> dict[int, str]:
    mapping = style_role_map(config)
    headings = {
        item.strip()
        for item in config["roles"]["section_heading"].get("examples", [])
    }
    roles: dict[object, str] = {}
    main_paragraphs = list(iter_container_paragraphs(document))
    first_nonempty_id = None
    if auto_classify:
        for paragraph in main_paragraphs:
            if paragraph.text.strip():
                first_nonempty_id = paragraph._p
                break
    main_ids = {paragraph._p for paragraph in main_paragraphs}
    for paragraph in iter_all_paragraphs(document):
        paragraph_id = paragraph._p
        role_name = mapping.get(paragraph.style.name, "body_and_other")
        text = paragraph.text.strip().rstrip("：:")
        if text in headings:
            role_name = "section_heading"
        if auto_classify and paragraph_id == first_nonempty_id:
            role_name = "document_title"
        if paragraph_id not in main_ids and role_name == "document_title":
            role_name = "body_and_other"
        roles[paragraph_id] = role_name
    return roles


def apply_document(
    document: DocumentObject,
    config: dict,
    auto_classify: bool,
    replace_paragraph_styles: bool,
) -> None:
    installed = install_styles(document, config)
    roles = classify_paragraphs(document, config, auto_classify)
    for paragraph in iter_all_paragraphs(document):
        role_name = roles[paragraph._p]
        role = config["roles"][role_name]
        if replace_paragraph_styles:
            paragraph.style = installed[role_name]
        set_two_character_indent(
            paragraph,
            role["first_line_indent_chars"],
            role["first_line_indent_fallback_pt"],
        )
        for run in paragraph.runs:
            set_run_role(run, role)


def create_reference(output_path: Path, config: dict) -> None:
    document = Document()
    install_styles(document, config)

    title = document.add_paragraph(style=config["roles"]["document_title"]["style_name"])
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.add_run("法律文书格式示例 Legal Document Style")

    heading_one = document.add_paragraph(style=config["roles"]["section_heading"]["style_name"])
    heading_one.add_run("诉讼请求 Claims")

    body_one = document.add_paragraph(style=config["roles"]["body_and_other"]["style_name"])
    body_one.add_run(
        "本段用于展示正文及其他内容：中文使用仿宋，English text uses Times New Roman，字号均为小四。"
    )

    heading_two = document.add_paragraph(style=config["roles"]["section_heading"]["style_name"])
    heading_two.add_run("事实和理由 Facts and Reasons")

    body_two = document.add_paragraph(style=config["roles"]["body_and_other"]["style_name"])
    body_two.add_run(
        "所有段落均设置首行缩进两字符。本文件仅用于核对字体、字号、加粗及缩进，不设定页边距、行距或其他版式。"
    )

    apply_document(document, config, auto_classify=False, replace_paragraph_styles=False)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    document.save(output_path)


def rfonts_values(style_or_run) -> dict[str, str | None]:
    if hasattr(style_or_run, "_r"):
        rpr = style_or_run._r.rPr
    else:
        rpr = style_or_run._element.rPr
    rfonts = None if rpr is None else rpr.find(qn("w:rFonts"))
    if rfonts is None:
        return {key: None for key in ("eastAsia", "ascii", "hAnsi", "cs")}
    return {
        key: rfonts.get(qn(f"w:{key}"))
        for key in ("eastAsia", "ascii", "hAnsi", "cs")
    }


def indent_values(paragraph_or_style) -> tuple[str | None, str | None]:
    if isinstance(paragraph_or_style, Paragraph):
        ppr = paragraph_or_style._p.pPr
    else:
        ppr = paragraph_or_style._element.pPr
    ind = None if ppr is None else ppr.find(qn("w:ind"))
    if ind is None:
        return None, None
    return ind.get(qn("w:firstLineChars")), ind.get(qn("w:firstLine"))


def close_enough(value: float | None, expected: float, tolerance: float = 0.05) -> bool:
    return value is not None and math.isclose(value, expected, abs_tol=tolerance)


def verify_document(document_path: Path, config: dict) -> dict:
    document = Document(document_path)
    failures: list[str] = []
    checks = 0

    for role_name, role in config["roles"].items():
        style_name = role["style_name"]
        if style_name not in document.styles:
            failures.append(f"missing style: {style_name}")
            continue
        style = document.styles[style_name]
        fonts = rfonts_values(style)
        for slot in ("ascii", "hAnsi", "cs"):
            checks += 1
            if fonts[slot] != role["latin_font"]:
                failures.append(f"{style_name} {slot}: {fonts[slot]!r}")
        checks += 1
        if fonts["eastAsia"] != role["chinese_font"]:
            failures.append(f"{style_name} eastAsia: {fonts['eastAsia']!r}")
        size = None if style.font.size is None else style.font.size.pt
        checks += 1
        if not close_enough(size, role["font_size_pt"]):
            failures.append(f"{style_name} size: {size!r}")
        if role["bold"] is not None:
            checks += 1
            if style.font.bold is not bool(role["bold"]):
                failures.append(f"{style_name} bold: {style.font.bold!r}")
        chars, first_line = indent_values(style)
        checks += 2
        if chars != str(role["first_line_indent_chars"] * 100):
            failures.append(f"{style_name} firstLineChars: {chars!r}")
        expected_twips = str(round(role["first_line_indent_fallback_pt"] * 20))
        if first_line != expected_twips:
            failures.append(f"{style_name} firstLine: {first_line!r}")

    paragraph_count = 0
    role_mapping = style_role_map(config)
    for paragraph in iter_all_paragraphs(document):
        paragraph_count += 1
        role_name = role_mapping.get(paragraph.style.name, "body_and_other")
        role = config["roles"][role_name]
        chars, first_line = indent_values(paragraph)
        checks += 2
        if chars != str(role["first_line_indent_chars"] * 100):
            failures.append(f"paragraph {paragraph_count} firstLineChars: {chars!r}")
        expected_twips = str(round(role["first_line_indent_fallback_pt"] * 20))
        if first_line != expected_twips:
            failures.append(f"paragraph {paragraph_count} firstLine: {first_line!r}")
        for run_index, run in enumerate(paragraph.runs, start=1):
            fonts = rfonts_values(run)
            checks += 4
            if fonts["eastAsia"] != role["chinese_font"]:
                failures.append(
                    f"paragraph {paragraph_count} run {run_index} eastAsia: {fonts['eastAsia']!r}"
                )
            for slot in ("ascii", "hAnsi", "cs"):
                if fonts[slot] != role["latin_font"]:
                    failures.append(
                        f"paragraph {paragraph_count} run {run_index} {slot}: {fonts[slot]!r}"
                    )
            size = None if run.font.size is None else run.font.size.pt
            checks += 1
            if not close_enough(size, role["font_size_pt"]):
                failures.append(
                    f"paragraph {paragraph_count} run {run_index} size: {size!r}"
                )
            if role["bold"] is not None:
                checks += 1
                if run.bold is not bool(role["bold"]):
                    failures.append(
                        f"paragraph {paragraph_count} run {run_index} bold: {run.bold!r}"
                    )

    return {
        "ok": not failures,
        "document": str(document_path.resolve()),
        "checks": checks,
        "paragraphs": paragraph_count,
        "failures": failures,
    }


def parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    subparsers = parser.add_subparsers(dest="command", required=True)

    create_parser = subparsers.add_parser("create-reference")
    create_parser.add_argument("output", type=Path)

    apply_parser = subparsers.add_parser("apply")
    apply_parser.add_argument("input", type=Path)
    apply_parser.add_argument("output", type=Path)
    apply_parser.add_argument("--auto-classify", action="store_true")
    apply_parser.add_argument("--replace-paragraph-styles", action="store_true")

    verify_parser = subparsers.add_parser("verify")
    verify_parser.add_argument("input", type=Path)
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    args = parse_args(argv)
    config = load_config(args.config)

    if args.command == "create-reference":
        create_reference(args.output, config)
        print(json.dumps({"ok": True, "output": str(args.output.resolve())}, ensure_ascii=False))
        return 0

    if args.command == "apply":
        document = Document(args.input)
        apply_document(
            document,
            config,
            auto_classify=args.auto_classify,
            replace_paragraph_styles=args.replace_paragraph_styles,
        )
        args.output.parent.mkdir(parents=True, exist_ok=True)
        document.save(args.output)
        print(json.dumps({"ok": True, "output": str(args.output.resolve())}, ensure_ascii=False))
        return 0

    report = verify_document(args.input, config)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
